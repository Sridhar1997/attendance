<?php
session_destroy();
Header("Location: main_login.html");
?>
